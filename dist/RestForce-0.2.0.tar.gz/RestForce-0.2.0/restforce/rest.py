'''
Created on Mar 18, 2012

@author: dwingate
'''

from httplib2 import Http, MalformedHeader

def callRestMethod(sessionId, httpMethod, sfInstance, resourceName, jsonDataString="{}"):
    """
    Invokes a REST method on a salesforce resoruce, optionally passing a data paylod.
    If REST invocation fails, a RestInvocationException is raised.
    """
    restRequestHeaders = {
        "content-type":"application/json", 
        "Authorization":"OAuth " + sessionId, 
        "X-PrettyPrint":"1"
    }
    httpResource = "https://" + sfInstance + "/services/apexrest/" + resourceName
    h = Http()
    try:
        restResponse, restContent = h.request(httpResource, httpMethod, body=jsonDataString, headers=restRequestHeaders)
        if restResponse.status < 200 or restResponse.status > 299:
            raise RestInvocationException('Status ' + str(restResponse.status) + ': ' + restContent)
        return restContent
    except MalformedHeader:
        raise RestInvocationException('Invalid sessionId')

class RestInvocationException(Exception):
    '''
    Thrown to indicate that invocation of REST method resulted in a non-successful response code.
    '''
    pass