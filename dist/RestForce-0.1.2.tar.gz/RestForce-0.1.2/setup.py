from distutils.core import setup
import textwrap

setup(
    name='RestForce',
    version='0.1.2',
    author='Dave Wingate',
    author_email='davewingate+restforce@gmail.com',
    packages=['restforce'],
    scripts=[],
    url='http://pypi.python.org/pypi/RestForce/',
    license='MIT Expat License',
    description='A python API for accessing RESTful resources on the force.com platform.',
    long_description=textwrap.dedent( """\
        Usage
        =====

        Rest Force offers a python api for easily working with RESTful resources exposed
        by the `force.com platform <http://www.salesforce.com/platform/>`_. 
        Typical usage often looks like this::
        
            #!/usr/bin/python
        
            from restforce import foo
            from restforce import bar
        
            # TODO provide an example

        Motivation
        ==========
        # TODO
        
        Salesforce REST Example
        =======================
        # TODO

        """ ),
)