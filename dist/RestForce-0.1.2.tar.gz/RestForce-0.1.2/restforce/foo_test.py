'''
Created on Mar 11, 2012

@author: dwingate
'''
import unittest
from foo import doFoo

class FooTest(unittest.TestCase):

    def test_foo(self):
        self.assertEqual(123, doFoo())

if __name__ == "__main__":
    unittest.main()
