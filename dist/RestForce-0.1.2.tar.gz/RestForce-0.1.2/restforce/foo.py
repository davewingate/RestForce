'''
Created on Mar 11, 2012

@author: dwingate
'''

def doFoo():
    print "doFoo"
    return 123