'''
Created on Mar 11, 2012

@author: dwingate
'''

def doBar():
    print "doBar"
    return "Lorem ipsum ..."
    
