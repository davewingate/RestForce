'''
Created on Mar 11, 2012

@author: dwingate
'''

import foo
import bar

if __name__ == '__main__':
    foo.doFoo()
    bar.doBar()