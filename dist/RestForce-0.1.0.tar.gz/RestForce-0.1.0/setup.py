from distutils.core import setup

setup(
    name='RestForce',
    version='0.1.0',
    author='Dave Wingate',
    author_email='davewingate+restforce@gmail.com',
    packages=['restforce'],
    scripts=[],
    url='http://pypi.python.org/pypi/RestForce/',
    license='MIT Expat License',
    description='A python API for accessing RESTful resources on the force.com platform.',
    long_description=open('README.txt').read()
)