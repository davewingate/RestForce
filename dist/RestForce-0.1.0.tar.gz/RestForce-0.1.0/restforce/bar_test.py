'''
Created on Mar 11, 2012

@author: dwingate
'''
import unittest
from bar import doBar

class BarTest(unittest.TestCase):

    def test_bar(self):
        self.assertEqual("Lorem ipsum ...", doBar())

if __name__ == "__main__":
    unittest.main()
