'''
Created on Mar 18, 2012

@author: dwingate
'''
import unittest
from restforce.rest import callRestMethod, RestInvocationException

class Test(unittest.TestCase):


    def testCallRestMethod(self):
        sessionId = 'fooBarBaz'
        sfInstance = 'na10.salesforce.com'
        self.assertRaises(RestInvocationException, callRestMethod, sessionId, 'GET', sfInstance, 'no_such_resource')


if __name__ == "__main__":
    unittest.main()