from distutils.core import setup
import textwrap

setup(
    name='RestForce',
    version='0.2.3',
    author='Dave Wingate',
    author_email='davewingate+restforce@gmail.com',
    packages=['restforce'],
    url='http://pypi.python.org/pypi/RestForce/',
    license='MIT License',
    description='A python API for accessing RESTful resources on the force.com platform.',
    long_description=textwrap.dedent( """\
    
        Usage
        =====

        Rest Force offers a python api for easily working with RESTful resources exposed
        by the `force.com platform <http://www.salesforce.com/platform/>`_. 
        Typical usage often looks like this::
        
            #!/usr/bin/python

            from restforce.login import loginFromCredentialsFile
            from restforce.rest import callRestMethod
            
            (sessionId, serverUrl, sfInstance) = loginFromCredentialsFile()
            
            newResourceAsJson = '{"salutation":"Hello", "firstName":"Bob", "lastName":"Smith"}'
            restResponse = callRestMethod(sessionId, 'POST', sfInstance, 'greeting', newResourceAsJson)
            
            print restResponse
        
        Salesforce REST Example
        =======================
        
        `Creating a REST resource <http://www.salesforce.com/us/developer/docs/apexcode/Content/apex_rest_code_sample_basic.htm>`_ on the force.com platform is easy.  Here's an example:::
        
            @RestResource(urlMapping='/greeting/*')
            global class GreetingResource {
                
                @HttpPost
                global static Greeting__c createGreeting(String salutation, String firstName, String lastName) 
                {
                
                    final Salutation__c salutationByName = getOrCreateSalutation(salutation);
                    
                    final Contact recipientByName = getOrCreateRecipient(firstName, lastName);
                    
                    Greeting__c greeting = new Greeting__c();
                    greeting.salutation__c = salutationByName.Id;
                    greeting.recipient__c = recipientByName.Id;
                    insert greeting;
                    
                    return forResourceResponse(greeting);
                }
                
                @HttpGet
                global static Greeting__c getGreetingById() 
                {
                    final Id greetingId = getGreetingIdFromRestRequestUri();
                    final Greeting__c greetingById = getGreetingById(greetingId);
                    
                    if (greetingById == null) {
                        setRestResponseStatusCode(404);
                    }
                    
                    return forResourceResponse(greetingById);
                }
            
                @HttpDelete
                global static void deleteGreetingById() 
                {
                    final Id greetingId = getGreetingIdFromRestRequestUri();
                    final Greeting__c greetingById = getGreetingById(greetingId);
                    
                    if (greetingById == null) {
                        setRestResponseStatusCode(404);
                    }
                    else {
                        delete greetingById;
                    }
                }
                
            }

        """),
      classifiers=['Development Status :: 1 - Planning', 'Environment :: Console', 'Intended Audience :: Developers', 'License :: OSI Approved :: MIT License', 'Natural Language :: English', 'Operating System :: OS Independent', 'Topic :: Internet :: WWW/HTTP'],
)